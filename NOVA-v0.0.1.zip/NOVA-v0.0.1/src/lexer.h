#ifndef NOVA_LEXER_H
#define NOVA_LEXER_H

#include <stddef.h>

typedef enum {
    TOK_EOF, TOK_NUMBER, TOK_STRING, TOK_SAY,
    TOK_PLUS, TOK_MINUS, TOK_STAR, TOK_SLASH,
    TOK_LPAREN, TOK_RPAREN, TOK_INVALID
} TokenType;

typedef struct {
    TokenType type;
    const char *start;
    size_t length;
    double number;
    int line;
} Token;

typedef struct {
    const char *source;
    size_t position;
    int line;
} Lexer;

void lexer_init(Lexer *lexer, const char *source);
Token lexer_next(Lexer *lexer);
const char *token_type_name(TokenType type);

#endif
