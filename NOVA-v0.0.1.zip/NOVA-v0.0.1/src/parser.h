#ifndef NOVA_PARSER_H
#define NOVA_PARSER_H

#include "lexer.h"

typedef enum { VALUE_NUMBER, VALUE_STRING } ValueType;

typedef struct {
    ValueType type;
    double number;
    const char *string;
    size_t string_length;
} Value;

typedef struct {
    Lexer lexer;
    Token current;
    int had_error;
} Parser;

void parser_init(Parser *parser, const char *source);
int parser_run(Parser *parser);

#endif
