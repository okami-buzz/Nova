#include "runtime.h"
#include <math.h>
#include <stdio.h>

void runtime_print_value(Value value) {
    if (value.type == VALUE_STRING) {
        printf("%.*s\n", (int)value.string_length, value.string);
        return;
    }
    if (isfinite(value.number) && value.number == (long long)value.number &&
        value.number >= -9007199254740991.0 && value.number <= 9007199254740991.0) {
        printf("%.0f\n", value.number);
    } else {
        printf("%.15g\n", value.number);
    }
}
