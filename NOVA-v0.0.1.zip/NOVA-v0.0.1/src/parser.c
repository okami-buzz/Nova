#include "parser.h"
#include "runtime.h"
#include <math.h>
#include <stdio.h>

static void advance_token(Parser *parser) { parser->current = lexer_next(&parser->lexer); }

static void report_error(Parser *parser, int line, const char *message) {
    fprintf(stderr, "NOVA error [line %d]: %s\n", line, message);
    parser->had_error = 1;
}

static int consume(Parser *parser, TokenType expected, const char *message) {
    if (parser->current.type == expected) { advance_token(parser); return 1; }
    report_error(parser, parser->current.line, message);
    return 0;
}

static int parse_expression(Parser *parser, Value *out);

static int parse_primary(Parser *parser, Value *out) {
    Token token = parser->current;
    if (token.type == TOK_NUMBER) {
        out->type = VALUE_NUMBER; out->number = token.number;
        out->string = NULL; out->string_length = 0;
        advance_token(parser); return 1;
    }
    if (token.type == TOK_STRING) {
        out->type = VALUE_STRING; out->string = token.start;
        out->string_length = token.length; out->number = 0.0;
        advance_token(parser); return 1;
    }
    if (token.type == TOK_LPAREN) {
        advance_token(parser);
        if (!parse_expression(parser, out)) return 0;
        return consume(parser, TOK_RPAREN, "Expected ')' after expression.");
    }
    if (token.type == TOK_MINUS) {
        advance_token(parser);
        if (!parse_primary(parser, out)) return 0;
        if (out->type != VALUE_NUMBER) {
            report_error(parser, token.line, "Unary '-' can only be used with a number.");
            return 0;
        }
        out->number = -out->number; return 1;
    }
    if (token.type == TOK_INVALID)
        report_error(parser, token.line, "Unknown token. Check spelling or supported syntax.");
    else
        report_error(parser, token.line, "Expected a number, string, or '(' expression ')'.");
    return 0;
}

static int parse_factor(Parser *parser, Value *out) {
    if (!parse_primary(parser, out)) return 0;
    while (parser->current.type == TOK_STAR || parser->current.type == TOK_SLASH) {
        Token op = parser->current; advance_token(parser);
        Value right;
        if (!parse_primary(parser, &right)) return 0;
        if (out->type != VALUE_NUMBER || right.type != VALUE_NUMBER) {
            report_error(parser, op.line, "Arithmetic operators require numbers."); return 0;
        }
        if (op.type == TOK_SLASH && right.number == 0.0) {
            report_error(parser, op.line, "Division by zero is not allowed."); return 0;
        }
        out->number = op.type == TOK_STAR ? out->number * right.number : out->number / right.number;
        if (!isfinite(out->number)) {
            report_error(parser, op.line, "Number is outside the supported range."); return 0;
        }
    }
    return 1;
}

static int parse_expression(Parser *parser, Value *out) {
    if (!parse_factor(parser, out)) return 0;
    while (parser->current.type == TOK_PLUS || parser->current.type == TOK_MINUS) {
        Token op = parser->current; advance_token(parser);
        Value right;
        if (!parse_factor(parser, &right)) return 0;
        if (out->type != VALUE_NUMBER || right.type != VALUE_NUMBER) {
            report_error(parser, op.line, "Arithmetic operators require numbers."); return 0;
        }
        out->number = op.type == TOK_PLUS ? out->number + right.number : out->number - right.number;
        if (!isfinite(out->number)) {
            report_error(parser, op.line, "Number is outside the supported range."); return 0;
        }
    }
    return 1;
}

void parser_init(Parser *parser, const char *source) {
    lexer_init(&parser->lexer, source);
    parser->had_error = 0;
    advance_token(parser);
}

int parser_run(Parser *parser) {
    while (parser->current.type != TOK_EOF) {
        if (parser->current.type != TOK_SAY) {
            report_error(parser, parser->current.line,
                         "Each statement must start with 'say' in NOVA v0.0.1.");
            return 1;
        }
        int statement_line = parser->current.line;
        advance_token(parser);
        Value value;
        if (!parse_expression(parser, &value)) return 1;
        if (parser->current.type != TOK_EOF && parser->current.line == statement_line) {
            report_error(parser, parser->current.line, "Unexpected token after the expression.");
            return 1;
        }
        runtime_print_value(value);
        if (parser->current.type == TOK_INVALID) {
            report_error(parser, parser->current.line, "Unknown token.");
            return 1;
        }
    }
    return parser->had_error ? 1 : 0;
}
