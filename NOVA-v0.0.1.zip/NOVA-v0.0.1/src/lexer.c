#include "lexer.h"

#include <ctype.h>
#include <stdlib.h>
#include <string.h>

static char peek(const Lexer *lexer) { return lexer->source[lexer->position]; }

static char advance(Lexer *lexer) {
    char c = lexer->source[lexer->position];
    if (c != '\0') lexer->position++;
    return c;
}

static Token make_token(Lexer *lexer, TokenType type, size_t start, int line) {
    Token token;
    token.type = type;
    token.start = lexer->source + start;
    token.length = lexer->position - start;
    token.number = 0.0;
    token.line = line;
    return token;
}

void lexer_init(Lexer *lexer, const char *source) {
    lexer->source = source;
    lexer->position = 0;
    lexer->line = 1;
}

Token lexer_next(Lexer *lexer) {
    while (peek(lexer) != '\0') {
        char c = peek(lexer);
        if (c == ' ' || c == '\t' || c == '\r') { advance(lexer); continue; }
        if (c == '\n') { advance(lexer); lexer->line++; continue; }
        break;
    }

    size_t start = lexer->position;
    int line = lexer->line;
    char c = advance(lexer);
    if (c == '\0') return make_token(lexer, TOK_EOF, start, line);

    switch (c) {
        case '+': return make_token(lexer, TOK_PLUS, start, line);
        case '-': return make_token(lexer, TOK_MINUS, start, line);
        case '*': return make_token(lexer, TOK_STAR, start, line);
        case '/': return make_token(lexer, TOK_SLASH, start, line);
        case '(': return make_token(lexer, TOK_LPAREN, start, line);
        case ')': return make_token(lexer, TOK_RPAREN, start, line);
        case '"': {
            while (peek(lexer) != '\0' && peek(lexer) != '"') {
                if (peek(lexer) == '\n') return make_token(lexer, TOK_INVALID, start, line);
                advance(lexer);
            }
            if (peek(lexer) == '\0') return make_token(lexer, TOK_INVALID, start, line);
            advance(lexer);
            Token token = make_token(lexer, TOK_STRING, start, line);
            token.start++;
            token.length -= 2;
            return token;
        }
        default: break;
    }

    if (isdigit((unsigned char)c) || (c == '.' && isdigit((unsigned char)peek(lexer)))) {
        int saw_dot = (c == '.');
        while (isdigit((unsigned char)peek(lexer)) || (!saw_dot && peek(lexer) == '.')) {
            if (peek(lexer) == '.') saw_dot = 1;
            advance(lexer);
        }
        Token token = make_token(lexer, TOK_NUMBER, start, line);
        char *end = NULL;
        token.number = strtod(token.start, &end);
        if (end != token.start + token.length) token.type = TOK_INVALID;
        return token;
    }

    if (isalpha((unsigned char)c) || c == '_') {
        while (isalnum((unsigned char)peek(lexer)) || peek(lexer) == '_') advance(lexer);
        Token token = make_token(lexer, TOK_INVALID, start, line);
        if (token.length == 3 && strncmp(token.start, "say", 3) == 0) token.type = TOK_SAY;
        return token;
    }
    return make_token(lexer, TOK_INVALID, start, line);
}

const char *token_type_name(TokenType type) {
    switch (type) {
        case TOK_EOF: return "end of input";
        case TOK_NUMBER: return "number";
        case TOK_STRING: return "string";
        case TOK_SAY: return "'say'";
        case TOK_PLUS: return "'+'";
        case TOK_MINUS: return "'-'";
        case TOK_STAR: return "'*'";
        case TOK_SLASH: return "'/'";
        case TOK_LPAREN: return "'('";
        case TOK_RPAREN: return "')'";
        case TOK_INVALID: return "unknown token";
    }
    return "unknown token";
}
