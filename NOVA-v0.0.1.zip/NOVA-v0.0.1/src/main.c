#include "parser.h"
#include <stdio.h>
#include <stdlib.h>

static char *read_file(const char *path) {
    FILE *file = fopen(path, "rb");
    if (file == NULL) { fprintf(stderr, "NOVA: Could not open '%s'.\n", path); return NULL; }
    if (fseek(file, 0, SEEK_END) != 0) {
        fprintf(stderr, "NOVA: Could not read '%s'.\n", path); fclose(file); return NULL;
    }
    long length = ftell(file);
    if (length < 0 || fseek(file, 0, SEEK_SET) != 0) {
        fprintf(stderr, "NOVA: Could not determine file size for '%s'.\n", path); fclose(file); return NULL;
    }
    char *buffer = malloc((size_t)length + 1);
    if (buffer == NULL) { fprintf(stderr, "NOVA: Not enough memory to read program.\n"); fclose(file); return NULL; }
    size_t bytes_read = fread(buffer, 1, (size_t)length, file);
    if (bytes_read != (size_t)length && ferror(file)) {
        fprintf(stderr, "NOVA: Error while reading '%s'.\n", path); free(buffer); fclose(file); return NULL;
    }
    buffer[bytes_read] = '\0'; fclose(file); return buffer;
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "NOVA v0.0.1\nUsage: %s <file.nova>\n", argv[0]);
        return 2;
    }
    char *source = read_file(argv[1]);
    if (source == NULL) return 2;
    Parser parser; parser_init(&parser, source);
    int result = parser_run(&parser);
    free(source);
    return result;
}
