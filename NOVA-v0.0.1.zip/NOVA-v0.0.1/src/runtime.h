#ifndef NOVA_RUNTIME_H
#define NOVA_RUNTIME_H
#include "parser.h"
void runtime_print_value(Value value);
#endif
