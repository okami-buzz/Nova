#!/bin/sh
set -eu
actual_file="$(mktemp)"
expected_file="$(mktemp)"
program_file="$(mktemp)"
error_file="$(mktemp)"
trap 'rm -f "$actual_file" "$expected_file" "$program_file" "$error_file"' EXIT
./nova examples/hello.nova > "$actual_file"
sed '/^[[:space:]]*$/d' tests/expected.txt > "$expected_file"
diff -u "$expected_file" "$actual_file"
printf 'say 5 / 0\n' > "$program_file"
if ./nova "$program_file" > /dev/null 2> "$error_file"; then
  echo "FAIL: division by zero should return an error" >&2
  exit 1
fi
grep -q "Division by zero" "$error_file"
./nova examples/math.nova > /dev/null
echo "NOVA tests: PASS"
